package org.springframework.context.support;

import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamReader;

import org.springframework.context.ApplicationContext;

public class ClassPathXmlApplicationContext implements ApplicationContext{
	private HashMap<String, Object> beans= new HashMap<>();

	public ClassPathXmlApplicationContext(String xmlFileName){
		try {
			Beans beansTree= null;

			Beans bsob=null;
			Bean bob=null;
			ArrayList<Bean> bl= null;
			Property pob=null;
			ArrayList<Property> pl= null;
			ConstructorArg cob=null;
			ArrayList<ConstructorArg> cl= null;
			int numOfAttributes;
			
			//read xml file using a StAX parser
			XMLInputFactory factory= XMLInputFactory.newInstance();
			InputStream is= ClassLoader.getSystemResourceAsStream(xmlFileName);
			XMLStreamReader reader= factory.createXMLStreamReader(is);

			while(reader.hasNext()){
				int event= reader.next();

				switch(event) {
				case XMLStreamConstants.START_ELEMENT:
					switch(reader.getLocalName()) {
					case "beans" :
						//found beans root tag
						bsob= new Beans();
						bl= new ArrayList<>();
						break;
					case "bean":
						// new bean found
						bob= new Bean();
						pl= new ArrayList<>();
						cl= new ArrayList<>();

						//set id attribute
						if(reader.getAttributeLocalName(0).equals("id"))
							bob.setId(reader.getAttributeValue(0));
						else if(reader.getAttributeLocalName(1).equals("id"))
							bob.setId(reader.getAttributeValue(1));

						//set class attribute
						if(reader.getAttributeLocalName(0).equals("class"))
							bob.setClassName(reader.getAttributeValue(0));
						else if(reader.getAttributeLocalName(1).equals("class"))
							bob.setClassName(reader.getAttributeValue(1));
						break;
					case "property":
						//new property found
						pob= new Property();
						
						//check no of attributes
						numOfAttributes= reader.getAttributeCount();
						
						//set name attribute
						if(reader.getAttributeLocalName(0).equals("name"))
							pob.setName(reader.getAttributeValue(0));
						else if(reader.getAttributeLocalName(1).equals("name"))
							pob.setName(reader.getAttributeValue(1));
						
						//set value attribute
						if(reader.getAttributeLocalName(0).equals("value"))
							pob.setValue(reader.getAttributeValue(0));
						else if(numOfAttributes>1 && reader.getAttributeLocalName(1).equals("value"))
							pob.setValue(reader.getAttributeValue(1));
						//TODO for ref
						
						pl.add(pob);
						break;
					case "constructor-arg":
						//new constructor-arg found
						cob= new ConstructorArg();
						
						//check no of attributes
						numOfAttributes= reader.getAttributeCount();
						
						//set ref attribute
						if(reader.getAttributeLocalName(0).equals("ref"))
							cob.setRef(reader.getAttributeValue(0));
						else if(numOfAttributes>1 && reader.getAttributeLocalName(1).equals("ref"))
							cob.setRef(reader.getAttributeValue(1));
						
						//set type attribute
						if(reader.getAttributeLocalName(0).equals("type"))
							cob.setType(reader.getAttributeValue(0));
						else if(numOfAttributes>1 && reader.getAttributeLocalName(1).equals("type"))
							cob.setType(reader.getAttributeValue(1));
						
						//set value attribute
						if(reader.getAttributeLocalName(0).equals("value"))
							cob.setValue(reader.getAttributeValue(0));
						else if(numOfAttributes>1 && reader.getAttributeLocalName(1).equals("value"))
							cob.setValue(reader.getAttributeValue(1));
						
						cl.add(cob);
						break;
						
					default :
						System.err.println("Invalid tag name found : "+reader.getLocalName());
						break;
					}
					break;
				case XMLStreamConstants.END_ELEMENT:
					switch(reader.getLocalName()){
						case "beans":
							bsob.setBeans(bl);
							break;
						case "bean":
							bob.setProperties(pl);
							bob.setConstructorArgs(cl);
							
							bl.add(bob);
							break;
						default:
							//rest cases ignored for other tags closing point
							break;
					}
					break;
				default:
					//rest cases ignored for xml parser constants
					break;
				}
			}
			beansTree= bsob;

			processBeans(beansTree);
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

	private void processBeans(Beans beansTree) throws Exception{
		//list of bean ids that are made using dependency injection by constructor
		ArrayList<String> dicBeans= new ArrayList<>();
		
		do 
		for(Bean b: beansTree.getBeans()) {
			Object object= null;
			Class<?> beanClass= Class.forName(b.getClassName());
			
			//properties are set without constructor-arg so create object
			if(b.getConstructorArgs().isEmpty()) {
				object= beanClass.newInstance();
			}
			//dependency injection by constructor
			else {
				ArrayList<Object> vlist= new ArrayList<>();
				boolean refNotIntialized= false;
				
				List<ConstructorArg> templ= b.getConstructorArgs();
				int sizeTempl= templ.size();
				Class<?> cplist[]= new Class<?>[sizeTempl];
				int i=0;
				
				for(ConstructorArg ca: templ) {
					if(ca.getRef()!=null) {
						Object temp= beans.get(ca.getRef()); 
						//referred value bean does not exist
						if(temp==null) {
							//add id of that bean to list of dicBeans
							dicBeans.add(b.getId());
							refNotIntialized=true;
							break;
						}
						//referred value is an existing bean
						else {
							cplist[i++]=temp.getClass();
							vlist.add(temp);
						}
					}
				}
				
				if(!refNotIntialized) {
					// get appropriate match
					setValidConstructor(beanClass.getConstructors(), cplist, vlist);
					
					//bean made using constructor
					object= beanClass.getConstructor(cplist).newInstance(vlist.toArray());
					//find bean id in dicBeans
					int index= dicBeans.indexOf(b.getId());
					//if exists then remove it from list as object is created now
					if(index!=-1)
						dicBeans.remove(index);
				}
			}
			
			if(object!=null) {
				//set data using setters
				for(Property p: b.getProperties()) {
					//when variable is a primitive data type
					if(p.getRef()==null) {
						String name= p.getName();
						String Uname= (char)(name.charAt(0)-32) + name.substring(1);
						String value= p.getValue();
						
						Object pdt=value;
						Class<?> clazz= beanClass.getDeclaredField(name).getType();
						if( boolean.class == clazz ) pdt= Boolean.parseBoolean( value );
						else if( byte.class == clazz ) pdt= Byte.parseByte( value );
						else if( short.class == clazz ) pdt= Short.parseShort( value );
						else if( int.class == clazz ) pdt= Integer.parseInt( value );
						else if( long.class == clazz ) pdt= Long.parseLong( value );
						else if( float.class == clazz ) pdt= Float.parseFloat( value );
						else if( double.class == clazz ) pdt= Double.parseDouble( value );
						else if( char.class == clazz ) pdt= value.charAt(0);
						
						//set data using setters
						beanClass.getMethod("set"+Uname, beanClass.getDeclaredField(name).getType()).invoke(object, pdt);
					}
				}
			}

			//add bean object in beans map
			beans.put(b.getId(), object);
		}
		while(!dicBeans.isEmpty());
	}
	
	private void setValidConstructor(Constructor<?> constructors[], Class<?> c1[], ArrayList<?> al) throws Exception{
		//HashMap<Class<?>, ArrayList<?>> map= new HashMap<>();
		Class<?> c2[];
		
		for(Constructor<?> constructor: constructors) {
			c2=constructor.getParameterTypes();
			
			if(c2.length!= c1.length)
				continue;
			
			int i=0,j=0;
			int found= 0;
			//c2 is const params of class
			//c1 is const params of xml const-arg
			for(i=0; i<c2.length; i++) {
				for(j=0; j<c1.length;j++) {
					//search constructor class in our args
					
					compare classes//if(c1[j]==c2[i]) {
						if(i!=j) {
							not swap but shift
//							Class<?> temp= c1[j];
//							c1[j]= c1[i];
//							c1[i]= temp;
//							
//							Collections.swap(al, i, j);
						}
						found++;
					}
				}
			}
			if(found==c2.length)
				return;
		}
		throw new IllegalArgumentException("No such constructor defined");
	}

	@Override
	public Object getBean(String beanName){
		//return the bean object
		return beans.get(beanName);
	}
}


/*
//read xml by JAXB
File file= new File(xmlFileName);
JAXBContext jaxbContext= JAXBContext.newInstance(Beans.class);
Unmarshaller unmarshaller= jaxbContext.createUnmarshaller();
Beans beansTree= (Beans)unmarshaller.unmarshal(file);
 */