package org.springframework.context.support;

import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="constructor-arg")
class ConstructorArg {
	@XmlAttribute(name="ref")
	private String ref;
	@XmlAttribute(name="type")
	private String type;
	@XmlAttribute(name="value")
	private String value;
	public String getRef() {
		return ref;
	}
	public void setRef(String ref) {
		this.ref = ref;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
}
