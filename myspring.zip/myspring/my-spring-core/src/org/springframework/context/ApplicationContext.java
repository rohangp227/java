package org.springframework.context;

public interface ApplicationContext{
	Object getBean(String beanName);
}