package spring;
public class Emp{
	private String name;
	public void setName(String name){
		this.name=name;
	}
	public String getName(){
		return name;
	}
}