package spring;
public class Address{
	private int hno;
	private String area;
	
	public void setHno(int hno){
		this.hno=hno;
	}
	public void setArea(String area){
		this.area=area;
	}
	
	public String toString(){
		return "Address{ hno: "+hno+", area: "+area+" }";
	}
}