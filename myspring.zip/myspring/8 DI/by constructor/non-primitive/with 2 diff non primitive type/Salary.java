package spring;
public class Salary{
	private int val;
	private int basic;
	
	public void setVal(int val){
		this.val=val;
	}
	public void setBasic(int basic){
		this.basic=basic;
	}
	
	public String toString(){
		return "Salary{ val: "+val+", basic: "+basic+" }";
	}
}