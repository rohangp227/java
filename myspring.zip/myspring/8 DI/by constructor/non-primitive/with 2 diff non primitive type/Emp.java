package spring;
public class Emp{
	private Salary sal;
	private Address addr1;
	private Address addr2;
	private String name;
	
	public Emp(Salary sal, Address addr1, Address addr2){
		System.out.println("in const of sal addr1 addr2");
		this.sal=sal;
		this.addr1=addr1;
		this.addr2=addr2;
	}
	
	public Emp(Address addr1, Address addr2, Salary sal){
		System.out.println("in const of addr1 addr2 sal");
		this.sal=sal;
		this.addr1=addr1;
		this.addr2=addr2;
	}
	//without setter of sal and default constr
	public void setName(String name){
		this.name=name;
	}
	
	public String toString(){
		return "Emp{ name: "+name+", sal: "+sal+", addr1:"+addr1+", addr2:"+addr2+" }";
	}
}