package spring;
public class Emp{
	private Salary sal;
	private String name;
	public Emp(Salary sal, String name){
		this.sal=sal;
		this.name=name;
	}
	//without setter of sal and default constr
	/*public String setName(){
		this.name=name;
	}*/
	
	public String toString(){
		return "Emp{ name: "+name+", sal: "+sal+" }";
	}
}