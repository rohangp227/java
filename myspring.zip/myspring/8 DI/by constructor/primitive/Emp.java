package spring;
public class Emp{
	private int id;
	private String name;
	public Emp(int id, String name){
		this.id=id;
		this.name=name;
	}
	//without setters and default constr
	/*public void setId(int id){
		this.id=id;
	}
	public void setName(String name){
		this.name=name;
	}*/
	public int getId(){
		return id;
	}
	public String getName(){
		return name;
	}
}